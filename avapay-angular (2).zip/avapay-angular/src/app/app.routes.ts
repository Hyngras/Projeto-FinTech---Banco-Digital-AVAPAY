import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AccountDetailsComponent } from './components/account-details/account-details.component';
import { TransactionListComponent } from './components/transaction-list/transaction-list.component';
import { PixFormComponent } from './components/pix-form/pix-form.component';
import { AddressFormComponent } from './components/address-form/address-form.component';
import { DepositComponent } from './components/deposit/deposit.component';
import { WithdrawComponent } from './components/withdraw/withdraw.component';
import { TransferComponent } from './components/transfer/transfer.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },                   // Tela inicial
  { path: 'login', component: LoginComponent },             // Login do cliente
  { path: 'admin-login', component: LoginComponent },       // Login do administrador (pode alterar depois)
  { path: 'register', component: RegisterComponent },     // Registro de novo usuário
  { path: 'dashboard', component: DashboardComponent },     // Dashboard do usuário
  { path: 'account', component: AccountDetailsComponent },  // Detalhes da conta
  { path: 'transactions', component: TransactionListComponent },  // Lista de transações
  { path: 'pix', component: PixFormComponent },             // Formulário de Pix
  { path: 'address', component: AddressFormComponent },     // Formulário de endereço
  { path: 'deposit', component: DepositComponent },         // Tela de Depósito
  { path: 'withdraw', component: WithdrawComponent },       // Tela de Saque
  { path: 'transfer', component: TransferComponent },       // Tela de Transferência

  // Redirecionar rotas desconhecidas para a Home
  { path: '**', redirectTo: '', pathMatch: 'full' }                             
];
