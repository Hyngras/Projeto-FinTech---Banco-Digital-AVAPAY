// src/app/models/pix.model.ts

export interface Pix {
    id?: number;
    key: string;
    keyType: 'CPF' | 'Email' | 'Phone' | 'Random';
    accountId: number;
  }
  