// src/app/models/transaction.model.ts

export interface Transaction {
    id?: number;
    amount: number;
    type: 'deposit' | 'withdraw' | 'transfer' | 'pix' | 'boleto';
    date?: Date;
    accountId: number;
  }
  