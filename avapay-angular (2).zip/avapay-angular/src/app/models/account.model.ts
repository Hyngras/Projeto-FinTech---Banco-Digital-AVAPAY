// src/app/models/account.model.ts

export interface Account {
    id?: number;
    accountNumber: string;
    balance: number;
    cpf: string;
  }
  