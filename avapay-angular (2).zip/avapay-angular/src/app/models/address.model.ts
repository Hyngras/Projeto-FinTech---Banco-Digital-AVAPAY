// src/app/models/address.model.ts

export interface Address {
    id?: number;
    street: string;
    number: string;
    city: string;
    state: string;
    zipCode: string;
    userId: number;
  }
  