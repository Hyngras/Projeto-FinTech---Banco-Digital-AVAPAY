import { ApplicationConfig, importProvidersFrom, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { provideClientHydration, withEventReplay } from '@angular/platform-browser';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideClientHydration(withEventReplay()),

    // Registro correto do HttpClient com interceptores do DI
    provideHttpClient(withInterceptorsFromDi()),

    // Adicionando os módulos necessários
    importProvidersFrom(CommonModule),   // Resolve o *ngIf
    importProvidersFrom(FormsModule),    // Resolve o ngModel
    importProvidersFrom(ReactiveFormsModule) // Resolve o formGroup
  ]
};
