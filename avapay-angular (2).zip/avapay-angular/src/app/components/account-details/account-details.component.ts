// src/app/components/account-details/account-details.component.ts

import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../services/account.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrl: './account-details.component.css',
  standalone: true,
  imports: []
})
export class AccountDetailsComponent implements OnInit {
  account: any;
  errorMessage: string = '';

  constructor(private accountService: AccountService, private authService: AuthService) {}

  ngOnInit(): void {
    this.loadAccountDetails();
  }

  loadAccountDetails(): void {
    if (this.authService.isLoggedIn()) {
      const userId = 1; // Substituir pela lógica de obtenção do ID do usuário autenticado

      this.accountService.getAccountDetails(userId).subscribe({
        next: (data) => {
          this.account = data;
        },
        error: (err) => {
          this.errorMessage = 'Erro ao carregar detalhes da conta: ' + err.error.message;
        }
      });
    } else {
      this.errorMessage = 'Usuário não autenticado.';
    }
  }
} 
