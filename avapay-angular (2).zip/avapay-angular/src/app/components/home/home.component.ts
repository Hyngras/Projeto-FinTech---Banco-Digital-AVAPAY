import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
  standalone: true,
  imports: [CommonModule]
})
export class HomeComponent {
  constructor(private router: Router) {}

  navigateToLogin(role: string): void {
    if (role === 'client') {
      this.router.navigate(['/login']);
    } else if (role === 'admin') {
      this.router.navigate(['/admin-login']);  // Rota para login de administrador
    }
  }
}
