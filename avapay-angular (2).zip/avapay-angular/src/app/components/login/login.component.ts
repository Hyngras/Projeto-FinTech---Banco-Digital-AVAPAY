// src/app/components/login/login.component.ts

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class LoginComponent {
  loginForm: FormGroup;  // Declarar o FormGroup corretamente
  errorMessage: string = '';

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    // Inicializando o formulário de login
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      this.authService.login(this.loginForm.value).subscribe({
        next: (response) => {
          localStorage.setItem('token', response.token);  // Salvar o token
          localStorage.setItem('userEmail', this.loginForm.value.email);  // Salvar o email para buscar dados do usuário
          this.router.navigate(['/dashboard']);  // Redirecionar para o dashboard
        },
        error: () => {
          this.errorMessage = 'Usuário ou senha inválidos!';
        }
      });
    } else {
      this.errorMessage = 'Preencha todos os campos corretamente!';
    }
  }
}
