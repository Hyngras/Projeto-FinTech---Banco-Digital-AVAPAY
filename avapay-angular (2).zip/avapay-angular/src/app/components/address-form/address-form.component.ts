import { Component } from '@angular/core';

@Component({
  selector: 'app-address-form',
  imports: [],
  templateUrl: './address-form.component.html',
  styleUrl: './address-form.component.css'
})
export class AddressFormComponent {

}
