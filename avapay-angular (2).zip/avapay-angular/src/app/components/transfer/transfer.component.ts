import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TransactionService } from '../../services/transaction.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class TransferComponent {
  transferForm: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(private fb: FormBuilder, private transactionService: TransactionService, private router: Router) {
    this.transferForm = this.fb.group({
      sourceAccount: ['', Validators.required],
      destinationAccount: ['', Validators.required],
      amount: ['', [Validators.required, Validators.min(1)]]
    });
  }

  onSubmit(): void {
    if (this.transferForm.valid) {
      this.transactionService.transfer(this.transferForm.value).subscribe({
        next: () => {
          this.successMessage = 'Transferência realizada com sucesso!';
          this.router.navigate(['/dashboard']);
        },
        error: (err) => {
          this.errorMessage = 'Erro ao realizar transferência: ' + err.error.message;
        }
      });
    }
  }

  cancel(): void {
    this.router.navigate(['/dashboard']);
  }
}
