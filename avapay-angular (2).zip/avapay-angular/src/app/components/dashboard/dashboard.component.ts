// src/app/components/dashboard/dashboard.component.ts
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  standalone: true,
  imports: [CommonModule]
})
export class DashboardComponent implements OnInit {
  userData: any = {};  // Armazena os dados do cliente
  errorMessage: string = '';

  constructor(private authService: AuthService, private userService: UserService) {}

  ngOnInit(): void {
    const email = this.authService.getUserEmail();  // Pega o email do localStorage

    if (email) {
      this.userService.getUserByEmail(email).subscribe({
        next: (data) => {
          this.userData = data;  // Dados do usuário carregados
        },
        error: (err) => {
          this.errorMessage = 'Erro ao carregar os dados do cliente.';
        }
      });
    }
  }
}
