// src/app/components/transaction-list/transaction-list.component.ts

import { Component, OnInit } from '@angular/core';
import { TransactionService } from '../../services/transaction.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-transaction-list',
  templateUrl: './transaction-list.component.html',
  styleUrl: './transaction-list.component.css',
  standalone: true,
  imports: []
})
export class TransactionListComponent implements OnInit {
  transactions: any[] = [];
  errorMessage: string = '';

  constructor(private transactionService: TransactionService, private authService: AuthService) {}

  ngOnInit(): void {
    this.loadTransactions();
  }

  loadTransactions(): void {
    if (this.authService.isLoggedIn()) {
      const userId = 1; // Substituir pela lógica de obtenção do ID do usuário autenticado

      this.transactionService.getTransactionsByUserId(userId).subscribe({
        next: (data) => {
          this.transactions = data;
        },
        error: (err) => {
          this.errorMessage = 'Erro ao carregar transações: ' + err.error.message;
        }
      });
    } else {
      this.errorMessage = 'Usuário não autenticado.';
    }
  }
} 
