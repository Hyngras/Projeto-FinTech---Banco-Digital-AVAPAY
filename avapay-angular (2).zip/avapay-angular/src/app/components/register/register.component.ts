import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class RegisterComponent {
  registerForm: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(private fb: FormBuilder, private userService: UserService, private router: Router) {
    this.registerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      cpf: ['', Validators.required],
      phone: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required],

      // Endereço
      street: ['', Validators.required],
      number: ['', Validators.required],
      complement: [''],
      cep: ['', Validators.required],
      neighborhood: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });
  }

  // Validação para confirmar se as senhas são iguais
  passwordMatchValidator(form: AbstractControl) {
    const password = form.get('password')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;

    if (password !== confirmPassword) {
      return { passwordMismatch: true };  // Retorna o erro se as senhas não coincidem
    }
    return null;  // Retorna null quando as senhas coincidem
  }

  // Submissão do formulário
  onSubmit(): void {
    if (this.registerForm.valid) {
      this.userService.createClient(this.registerForm.value).subscribe({
        next: () => {
          this.successMessage = 'Usuário registrado com sucesso!';
          setTimeout(() => this.router.navigate(['/login']), 1500);
        },
        error: (err) => {
          this.errorMessage = 'Erro ao registrar: ' + (err.error?.message || 'Tente novamente mais tarde.');
        }
      });
    } else {
      this.errorMessage = 'Preencha todos os campos obrigatórios corretamente.';
    }
  }
} 
