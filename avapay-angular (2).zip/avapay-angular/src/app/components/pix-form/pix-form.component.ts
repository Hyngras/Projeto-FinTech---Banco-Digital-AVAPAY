import { Component } from '@angular/core';

@Component({
  selector: 'app-pix-form',
  imports: [],
  templateUrl: './pix-form.component.html',
  styleUrl: './pix-form.component.css'
})
export class PixFormComponent {

}
