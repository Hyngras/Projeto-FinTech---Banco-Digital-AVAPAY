// src/app/services/account.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  private apiUrl = 'http://localhost:8080';  // URL base do backend

  constructor(private http: HttpClient) {}

  // Buscar detalhes da conta por ID do usuário
  getAccountDetails(userId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/account/${userId}`);
  }
} 
