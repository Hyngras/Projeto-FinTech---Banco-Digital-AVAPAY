// src/app/services/user.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'http://localhost:8080';  // URL base do backend

  constructor(private http: HttpClient) {}

  // Criar novo cliente (registro)
  createClient(clientData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, clientData);
  }

  // Buscar usuário pelo email (para carregar dados no dashboard)
  getUserByEmail(email: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/findByEmail/${email}`);
  }

  // Atualizar usuário
  updateUser(userId: number, userData: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/updateUser/${userId}`, userData);
  }

  // Buscar todos os usuários
  getAllUsers(): Observable<any> {
    return this.http.get(`${this.apiUrl}/findAll`);
  }

  // Buscar usuário por ID
  getUserById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/findById/${id}`);
  }

  // Buscar usuário por CPF
  getUserByCpf(cpf: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/findByCpf/${cpf}`);
  }

  // Deletar usuário
  deleteUser(userId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/deleteUser/${userId}`);
  }
}
