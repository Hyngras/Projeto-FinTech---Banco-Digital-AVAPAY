// src/app/services/transaction.service.ts 

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
  private apiUrl = 'http://localhost:8080';  // URL base do backend

  constructor(private http: HttpClient) {}

  // Buscar transações por ID do usuário
  getTransactionsByUserId(userId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/transactions/user/${userId}`);
  }

  // Depósito
  deposit(data: { accountNumber: string; agency: string; amount: number }): Observable<any> {
    return this.http.post(`${this.apiUrl}/transactions/deposit`, data);
  }

  // Saque
  withdraw(data: { accountNumber: string; amount: number }): Observable<any> {
    return this.http.post(`${this.apiUrl}/transactions/withdraw`, data);
  }

  // Transferência
  transfer(data: { 
    fromAccountNumber: string; 
    toAccountNumber: string; 
    agency: string; 
    amount: number 
  }): Observable<any> {
    return this.http.post(`${this.apiUrl}/transactions/transfer`, data);
  }
}
