package com.avapay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = AvapayProjetoSpringbootApplication.class)
public class AvapayProjetoSpringbootApplicationTests {

    @Test
    void contextLoads() {
        // Este teste básico verifica se o contexto da aplicação carrega corretamente.
    }
}
