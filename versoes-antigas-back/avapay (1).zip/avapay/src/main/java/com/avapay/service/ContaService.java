package com.avapay.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.avapay.model.Conta;
import com.avapay.repository.ContaRepository;

@Service
public class ContaService {

    @Autowired
    private ContaRepository contaRepository;

    // Cria uma nova conta sem verificação de duplicidade
    @Transactional
    public Conta criarConta(Conta conta) {
        return contaRepository.save(conta);
    }

    // Busca uma conta pelo ID
    public Optional<Conta> buscarPorId(Long id) {
        return contaRepository.findById(id);
    }

    // Busca uma conta pelo número
    public Optional<Conta> buscarPorNumeroConta(String numeroConta) {
        return contaRepository.findByNumeroConta(numeroConta);
    }

    public List<Conta> listarTodasContas() {
        return contaRepository.findAll();
    }

    // Remove uma conta pelo ID
    @Transactional
    public void removerConta(Long id) {
        if (!contaRepository.existsById(id)) {
            throw new ContaNaoEncontradaException("Conta não encontrada para exclusão.");
        }
        contaRepository.deleteById(id);
    }
}

// Exceções Personalizadas
class ContaNaoEncontradaException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public ContaNaoEncontradaException(String message) {
        super(message);
    }
}

class ContaJaExisteException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public ContaJaExisteException(String message) {
        super(message);
    }
}
