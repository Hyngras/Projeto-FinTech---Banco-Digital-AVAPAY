package com.avapay.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avapay.model.CadastroPix;
import com.avapay.model.Usuario;

@Repository
public interface CadastroPixRepository extends JpaRepository<CadastroPix, Long> {

    // Busca um CadastroPix pela chave cadastrada
    CadastroPix findByChaveCadastrada(String chaveCadastrada);

    // Verifica se já existe uma chave cadastrada com o valor informado
    boolean existsByChaveCadastrada(String chaveCadastrada);

    // Verifica se o usuário já possui uma chave Pix cadastrada
    boolean existsByUsuarioId(Long usuarioId);

    // Verifica se o usuário já possui uma chave Pix do mesmo tipo
    boolean existsByUsuarioAndChavePix(Usuario usuario, String chavePix);
}
