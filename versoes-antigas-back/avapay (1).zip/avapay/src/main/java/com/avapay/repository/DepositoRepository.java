package com.avapay.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avapay.model.Conta;
import com.avapay.model.Deposito;

@Repository
public interface DepositoRepository extends JpaRepository<Deposito, Long> {

    // Busca todos os depósitos realizados para uma conta de destino específica
    List<Deposito> findByContaDestino(Conta contaDestino);

    // Busca todos os depósitos ordenados por data e hora em ordem decrescente
    List<Deposito> findAllByOrderByDataHoraDesc();
}
