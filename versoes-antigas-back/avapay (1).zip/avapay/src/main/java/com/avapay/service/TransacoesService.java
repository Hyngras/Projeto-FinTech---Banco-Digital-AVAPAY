package com.avapay.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avapay.dto.TransacaoDTO;
import com.avapay.repository.TransacoesRepository;

@Service
public class TransacoesService {

    @Autowired
    private TransacoesRepository transacoesRepository;

    // Método para listar transações por conta e retornar como DTO, ordenadas por data decrescente
    public List<TransacaoDTO> listarTransacoesPorConta(Long contaId) {
        return transacoesRepository.findByContaOrigemIdOrContaDestinoId(contaId, contaId).stream()
                .sorted((t1, t2) -> t2.getDataHora().compareTo(t1.getDataHora()))
                .map(transacao -> new TransacaoDTO(
                        transacao.getTipoTransacao(),
                        transacao.getValor(),
                        transacao.getDataHora(),
                        transacao.getContaOrigem().getNumeroConta(),
                        transacao.getContaDestino().getNumeroConta()
                ))
                .collect(Collectors.toList());
    }
}
