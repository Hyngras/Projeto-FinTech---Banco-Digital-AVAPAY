package com.avapay.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.avapay.model.Conta;
import com.avapay.model.Pix;
import com.avapay.repository.CadastroPixRepository;
import com.avapay.repository.ContaRepository;
import com.avapay.repository.PixRepository;

@Service
public class PixService {

    @Autowired
    private PixRepository pixRepository;

    @Autowired
    private ContaRepository contaRepository;

    @Autowired
    private CadastroPixRepository cadastroPixRepository;

    // Realiza uma transferência Pix
    @Transactional
    public Pix realizarPix(Long contaOrigemId, Long contaDestinoId, BigDecimal valor) {
        Conta contaOrigem = contaRepository.findById(contaOrigemId)
                .orElseThrow(() -> new PixContaNaoEncontradaException("Conta de origem não encontrada."));
        Conta contaDestino = contaRepository.findById(contaDestinoId)
                .orElseThrow(() -> new PixContaNaoEncontradaException("Conta de destino não encontrada."));

        if (valor.compareTo(BigDecimal.ZERO) <= 0) {
            throw new PixValorInvalidoException("O valor da transferência Pix deve ser maior que zero.");
        }

        if (contaOrigem.getSaldo().compareTo(valor) < 0) {
            throw new PixSaldoInsuficienteException("Saldo insuficiente na conta de origem.");
        }

        if (contaOrigemId.equals(contaDestinoId)) {
            throw new PixTransferenciaInvalidaException("Não é possível fazer um Pix para a própria conta.");
        }

        validarChavePix(contaDestino);

        // Atualiza os saldos das contas
        contaOrigem.setSaldo(contaOrigem.getSaldo().subtract(valor));
        contaDestino.setSaldo(contaDestino.getSaldo().add(valor));
        contaRepository.save(contaOrigem);
        contaRepository.save(contaDestino);

        // Cria e salva a transação Pix
        Pix pix = new Pix();
        pix.setContaOrigem(contaOrigem);
        pix.setContaDestino(contaDestino);
        pix.setValor(valor);
        pix.setTipoTransacao("PIX");  // Definindo o tipo de transação automaticamente
        pix.setDataHora(LocalDateTime.now());

        return pixRepository.save(pix);
    }

    // Valida se a conta destino tem uma chave Pix cadastrada
    private void validarChavePix(Conta contaDestino) {
        if (!cadastroPixRepository.existsByUsuarioId(contaDestino.getUsuario().getId())) {
            throw new PixChaveNaoEncontradaException("Conta de destino não possui chave Pix cadastrada.");
        }
    }
}

// Exceções Personalizadas
class PixContaNaoEncontradaException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public PixContaNaoEncontradaException(String message) {
        super(message);
    }
}

class PixSaldoInsuficienteException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public PixSaldoInsuficienteException(String message) {
        super(message);
    }
}

class PixValorInvalidoException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public PixValorInvalidoException(String message) {
        super(message);
    }
}

class PixTransferenciaInvalidaException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public PixTransferenciaInvalidaException(String message) {
        super(message);
    }
}

class PixChaveNaoEncontradaException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public PixChaveNaoEncontradaException(String message) {
        super(message);
    }
}
