package com.avapay.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.avapay.model.CadastroPix;
import com.avapay.repository.CadastroPixRepository;

@Service
public class CadastroPixService {

    @Autowired
    private CadastroPixRepository cadastroPixRepository;

    // Cria um novo cadastro Pix
    @Transactional
    public CadastroPix criarCadastroPix(CadastroPix cadastroPix) {
        // Verifica se o usuário já possui uma chave Pix do mesmo tipo
        if (cadastroPixRepository.existsByUsuarioAndChavePix(cadastroPix.getUsuario(), cadastroPix.getChavePix())) {
            throw new ChavePixJaExisteException("Usuário já possui uma chave Pix do tipo: " + cadastroPix.getChavePix());
        }

        return cadastroPixRepository.save(cadastroPix);
    }

    // Busca um cadastro Pix pelo ID
    public Optional<CadastroPix> buscarPorId(Long id) {
        return cadastroPixRepository.findById(id);
    }

    // Busca um cadastro Pix pela chave cadastrada
    public Optional<CadastroPix> buscarPorChaveCadastrada(String chaveCadastrada) {
        return Optional.ofNullable(cadastroPixRepository.findByChaveCadastrada(chaveCadastrada));
    }

    // Lista todas as chaves Pix cadastradas
    public List<CadastroPix> buscarTodasChavesPix() {
        return cadastroPixRepository.findAll();
    }

    // Remove um cadastro Pix pelo ID
    @Transactional
    public void removerCadastroPix(Long id) {
        if (!cadastroPixRepository.existsById(id)) {
            throw new ChavePixNaoEncontradaException("Cadastro Pix não encontrado para exclusão.");
        }
        cadastroPixRepository.deleteById(id);
    }
}

// Exceções Personalizadas
class ChavePixNaoEncontradaException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public ChavePixNaoEncontradaException(String message) {
        super(message);
    }
}

class ChavePixJaExisteException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public ChavePixJaExisteException(String message) {
        super(message);
    }
}
