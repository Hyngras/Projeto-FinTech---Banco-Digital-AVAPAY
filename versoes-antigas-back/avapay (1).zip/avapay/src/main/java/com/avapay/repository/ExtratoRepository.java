package com.avapay.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avapay.model.Extrato;

@Repository
public interface ExtratoRepository extends JpaRepository<Extrato, Long> {

    // Busca todos os extratos ordenados por data de emissão em ordem decrescente
    List<Extrato> findAllByOrderByDataEmissaoDesc();

    List<Extrato> findByTransacaoContaOrigemIdOrTransacaoContaDestinoIdOrderByDataEmissaoDesc(Long contaOrigemId, Long contaDestinoId);

    // Busca extratos associados a transações de uma conta específica
    List<Extrato> findByTransacaoContaOrigemIdOrTransacaoContaDestinoId(Long contaOrigemId, Long contaDestinoId);
}