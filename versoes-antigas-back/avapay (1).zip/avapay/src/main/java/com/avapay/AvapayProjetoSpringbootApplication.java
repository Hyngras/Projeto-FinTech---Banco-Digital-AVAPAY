package com.avapay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvapayProjetoSpringbootApplication {

    public static void main(String[] args) {
        SpringApplication.run(AvapayProjetoSpringbootApplication.class, args);
    }
}
