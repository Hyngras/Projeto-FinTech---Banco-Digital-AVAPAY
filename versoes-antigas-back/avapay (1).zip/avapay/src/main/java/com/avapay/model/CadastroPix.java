package com.avapay.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "Cadastro_PIX")
public class CadastroPix {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_pix_cadastro")  // Correção: nome da coluna no banco
    private Long id;

    @Column(name = "Chave_cadastrada_pix", nullable = false, unique = true, length = 200)
    @NotBlank(message = "A chave cadastrada do Pix não pode estar vazia.")
    private String chaveCadastrada;

    @Column(name = "Chave_pix", nullable = false, length = 200)
    @NotBlank(message = "A chave Pix não pode estar vazia.")
    private String chavePix;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "ID_usuario", nullable = false, unique = true)
    private Usuario usuario;

    // Getters e Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getChaveCadastrada() {
        return chaveCadastrada;
    }

    public void setChaveCadastrada(String chaveCadastrada) {
        this.chaveCadastrada = chaveCadastrada;
    }

    public String getChavePix() {
        return chavePix;
    }

    public void setChavePix(String chavePix) {
        this.chavePix = chavePix;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
}
