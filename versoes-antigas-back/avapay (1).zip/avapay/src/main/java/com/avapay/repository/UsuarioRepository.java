package com.avapay.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avapay.model.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // Busca um usuário pelo CPF
    Usuario findByCpf(String cpf);

    // Busca um usuário pelo email
    Usuario findByEmail(String email);

    // Busca por número de conta e agência
    Usuario findByConta_NumeroContaAndConta_Agencia(String numeroConta, String agencia);

	List<Usuario> findByTipoUsuario_TipoUsuarioIgnoreCase(String tipoUsuario);

}
