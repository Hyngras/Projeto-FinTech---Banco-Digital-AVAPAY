package com.avapay.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.avapay.model.Conta;
import com.avapay.service.ContaService;

@RestController
@RequestMapping("/api/contas")
public class ContaController {

    @Autowired
    private ContaService contaService;

    // Endpoint para criar uma nova conta
    @PostMapping("/criar")
    public ResponseEntity<Conta> criarConta(@RequestBody Conta conta) {
        Conta novaConta = contaService.criarConta(conta);
        return ResponseEntity.ok(novaConta);
    }

    // Endpoint para buscar uma conta pelo ID
    @GetMapping("/{id}")
    public ResponseEntity<Conta> buscarContaPorId(@PathVariable Long id) {
        Optional<Conta> conta = contaService.buscarPorId(id);
        return conta.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // Endpoint para buscar uma conta pelo número da conta
    @GetMapping("/numero/{numeroConta}")
    public ResponseEntity<Conta> buscarPorNumeroConta(@PathVariable String numeroConta) {
        Optional<Conta> conta = contaService.buscarPorNumeroConta(numeroConta);
        return conta.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // Endpoint para listar todas as contas (opcional para administradores)
    @GetMapping("/todas")
    public ResponseEntity<List<Conta>> listarTodasContas() {
        List<Conta> contas = contaService.listarTodasContas();
        return ResponseEntity.ok(contas);
    }

    // Endpoint para remover uma conta pelo ID
    @DeleteMapping("/remover/{id}")
    public ResponseEntity<Void> removerConta(@PathVariable Long id) {
        contaService.removerConta(id);
        return ResponseEntity.noContent().build();
    }

}
