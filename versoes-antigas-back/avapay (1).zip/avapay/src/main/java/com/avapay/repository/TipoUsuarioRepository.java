package com.avapay.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avapay.model.TipoUsuario;
import com.avapay.model.Usuario;

@Repository
public interface TipoUsuarioRepository extends JpaRepository<TipoUsuario, Long> {

    // Busca o tipo de usuário pelo nome
    List<TipoUsuario> findByTipoUsuario(String tipoUsuario);
    
    List<Usuario> findByTipoUsuario_TipoUsuarioIgnoreCase(String tipoUsuario);

}
