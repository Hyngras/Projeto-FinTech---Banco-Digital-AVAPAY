package com.avapay.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avapay.model.TipoUsuario;
import com.avapay.repository.TipoUsuarioRepository;

@Service
public class TipoUsuarioService {

    @Autowired
    private TipoUsuarioRepository tipoUsuarioRepository;

    // Cria um novo tipo de usuário (permite múltiplos registros iguais)
    public TipoUsuario criarTipoUsuario(TipoUsuario tipoUsuario) {
        tipoUsuario.setTipoUsuario(tipoUsuario.getTipoUsuario().trim().toUpperCase());
        return tipoUsuarioRepository.save(tipoUsuario);
    }

    // Busca todos os tipos de usuário
    public List<TipoUsuario> listarTodos() {
        return tipoUsuarioRepository.findAll();
    }

    // Busca um tipo de usuário pelo ID
    public TipoUsuario buscarPorId(Long id) {
        return tipoUsuarioRepository.findById(id)
                .orElseThrow(() -> new TipoUsuarioNaoEncontradoException("Tipo de usuário não encontrado."));
    }

    // Remove um tipo de usuário por ID
    public void removerTipoUsuario(Long id) {
        if (!tipoUsuarioRepository.existsById(id)) {
            throw new TipoUsuarioNaoEncontradoException("Tipo de usuário não encontrado para exclusão.");
        }
        tipoUsuarioRepository.deleteById(id);
    }

    // Exceção personalizada para tipo de usuário não encontrado
    class TipoUsuarioNaoEncontradoException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        public TipoUsuarioNaoEncontradoException(String message) {
            super(message);
        }
    }
}
