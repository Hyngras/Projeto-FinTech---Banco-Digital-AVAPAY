package com.avapay.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.avapay.model.CadastroPix;
import com.avapay.service.CadastroPixService;

@RestController
@RequestMapping("/api/pix")
public class CadastroPixController {

    @Autowired
    private CadastroPixService cadastroPixService;

    // Endpoint para cadastrar uma nova chave Pix
    @PostMapping("/cadastrar")
    public ResponseEntity<CadastroPix> cadastrarChavePix(@RequestBody CadastroPix cadastroPix) {
        CadastroPix novaChave = cadastroPixService.criarCadastroPix(cadastroPix);
        return ResponseEntity.ok(novaChave);
    }

    // Endpoint para buscar uma chave Pix pela chave cadastrada
    @GetMapping("/chave/{chaveCadastrada}")
    public ResponseEntity<CadastroPix> buscarPorChaveCadastrada(@PathVariable String chaveCadastrada) {
        return cadastroPixService.buscarPorChaveCadastrada(chaveCadastrada)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
