package com.avapay.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.avapay.model.Extrato;
import com.avapay.model.Transacoes;
import com.avapay.repository.ExtratoRepository;
import com.avapay.repository.TransacoesRepository;

@Service
public class ExtratoService {

    @Autowired
    private ExtratoRepository extratoRepository;

    @Autowired
    private TransacoesRepository transacoesRepository;

    // Lista extratos associados a uma conta específica
    public List<Extrato> listarExtratosPorConta(Long contaId) {
        return extratoRepository.findByTransacaoContaOrigemIdOrTransacaoContaDestinoId(contaId, contaId);
    }

    // Gera um extrato baseado em uma transação
    @Transactional
    public Extrato gerarExtratoPorTransacao(Long transacaoId) {
        Transacoes transacao = transacoesRepository.findById(transacaoId)
                .orElseThrow(() -> new TransacaoNaoEncontradaException("Transação não encontrada."));

        Extrato extrato = new Extrato();
        extrato.setTransacao(transacao);
        extrato.setTipoTransacao(transacao.getTipoTransacao());  // Garantindo que o tipo da transação esteja correto
        extrato.setDataEmissao(transacao.getDataHora());

        return extratoRepository.save(extrato);
    }

    // Lista todos os extratos ordenados por data de emissão
    public List<Extrato> listarTodosExtratos() {
        return extratoRepository.findAllByOrderByDataEmissaoDesc();
    }

}

// Exceção Personalizada
class TransacaoNaoEncontradaException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    public TransacaoNaoEncontradaException(String message) {
        super(message);
    }
}
