package com.avapay.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avapay.dto.CriarUsuarioDTO;
import com.avapay.dto.UsuarioDTO;
import com.avapay.model.TipoUsuario;
import com.avapay.model.Usuario;
import com.avapay.repository.TipoUsuarioRepository;
import com.avapay.repository.UsuarioRepository;

import jakarta.transaction.Transactional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private TipoUsuarioRepository tipoUsuarioRepository;

    @Transactional
    public UsuarioDTO criarUsuario(CriarUsuarioDTO criarUsuarioDTO, boolean isAdmin) {
        if (!isAdmin && "ADM".equalsIgnoreCase(criarUsuarioDTO.getTipoUsuario())) {
            throw new IllegalArgumentException("Apenas administradores podem criar outros administradores.");
        }

        if (usuarioRepository.findByEmail(criarUsuarioDTO.getEmail()) != null) {
            throw new IllegalArgumentException("E-mail já cadastrado.");
        }
        if (usuarioRepository.findByCpf(criarUsuarioDTO.getCpf()) != null) {
            throw new IllegalArgumentException("CPF já cadastrado.");
        }

        // Buscar o tipo de usuário pelo nome (corrigido para evitar NullPointerException)
        String tipoUsuarioStr = criarUsuarioDTO.getTipoUsuario();
        if (tipoUsuarioStr == null || tipoUsuarioStr.trim().isEmpty()) {
            throw new IllegalArgumentException("O tipo de usuário não pode ser nulo ou vazio.");
        }

        List<TipoUsuario> tiposUsuario = tipoUsuarioRepository.findByTipoUsuario(tipoUsuarioStr.toUpperCase());

        if (tiposUsuario.isEmpty()) {
            throw new IllegalArgumentException("Tipo de usuário não encontrado. Certifique-se de que o tipo é 'ADMIN' ou 'CLIENTE'.");
        }

        TipoUsuario tipoUsuario = tiposUsuario.get(0);

        Usuario novoUsuario = new Usuario();
        novoUsuario.setNome(criarUsuarioDTO.getNome());
        novoUsuario.setCpf(criarUsuarioDTO.getCpf());
        novoUsuario.setEmail(criarUsuarioDTO.getEmail());
        novoUsuario.setTelefone(criarUsuarioDTO.getTelefone());
        novoUsuario.setEndereco(criarUsuarioDTO.getEndereco());
        novoUsuario.setSenha(criarUsuarioDTO.getSenha());
        novoUsuario.setTipoUsuario(tipoUsuario);

        usuarioRepository.save(novoUsuario);

        return new UsuarioDTO(
            novoUsuario.getId(),
            novoUsuario.getNome(),
            novoUsuario.getEmail(),
            novoUsuario.getTelefone(),
            novoUsuario.getTipoUsuario().getTipoUsuario()
        );
    }

    public List<UsuarioDTO> buscarUsuariosPorTipo(String tipoUsuario) {
        List<Usuario> usuarios = usuarioRepository.findByTipoUsuario_TipoUsuarioIgnoreCase(tipoUsuario);

        if (usuarios.isEmpty()) {
            throw new IllegalArgumentException("Nenhum usuário encontrado para o tipo: " + tipoUsuario);
        }

        return usuarios.stream()
                .map(usuario -> new UsuarioDTO(
                        usuario.getId(),
                        usuario.getNome(),
                        usuario.getEmail(),
                        usuario.getTelefone(),
                        usuario.getTipoUsuario().getTipoUsuario()))
                .collect(Collectors.toList());
    }

    @Transactional
    public void removerUsuario(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new IllegalArgumentException("Usuário não encontrado para exclusão.");
        }
        usuarioRepository.deleteById(id);
    }
}
