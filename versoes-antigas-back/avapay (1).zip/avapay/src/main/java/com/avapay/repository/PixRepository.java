package com.avapay.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avapay.model.Conta;
import com.avapay.model.Pix;

@Repository
public interface PixRepository extends JpaRepository<Pix, Long> {

    // Busca todos os Pix ordenados por data e hora em ordem decrescente
    List<Pix> findAllByOrderByDataHoraDesc();

    // Verifica se existe uma chave Pix cadastrada para a conta destino
    boolean existsByContaDestino(Conta contaDestino);
}
