### Relações @ManyToOne

- `Usuario`: Relaciona-se com `TipoUsuario`.
- `TipoUsuario`: Não possui relacionamentos.
- `Conta`: Relaciona-se com `Usuario`.
- `CadastroPix`: Relaciona-se com `Usuario`.
- `Endereco`: Relaciona-se com `Usuario`.
- `Transacoes`: Relaciona-se com `Conta` (origem e destino).
- `Pix`: Relaciona-se com `Conta` (origem e destino) e `Transacoes`.
- `Deposito`: Relaciona-se com `Conta` (origem e destino) e `Transacoes`.
- `Saque`: Relaciona-se com `Conta` e `Transacoes`.
- `Extrato`: Relaciona-se com `Transacoes`.
