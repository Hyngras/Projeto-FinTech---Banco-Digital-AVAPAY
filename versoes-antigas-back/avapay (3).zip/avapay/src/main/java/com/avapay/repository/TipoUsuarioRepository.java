package com.avapay.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avapay.model.TipoUsuario;

public interface TipoUsuarioRepository extends JpaRepository<TipoUsuario, Long> {

    // Busca o tipo de usuário pelo nome (equivalente ao findByRoleName no projeto base)
    Optional<TipoUsuario> findByNomeTipoUsuario(String nomeTipoUsuario);
}
