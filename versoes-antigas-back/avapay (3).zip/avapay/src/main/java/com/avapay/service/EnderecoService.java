package com.avapay.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avapay.dto.EnderecoDTO;
import com.avapay.model.Endereco;
import com.avapay.model.Usuario;
import com.avapay.repository.EnderecoRepository;
import com.avapay.repository.UsuarioRepository;

import jakarta.transaction.Transactional;

@Service
public class EnderecoService {

    @Autowired
    private EnderecoRepository enderecoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Atualizar endereço do usuário
    @Transactional
    public Endereco atualizarEnderecoUsuario(Long usuarioId, EnderecoDTO enderecoDTO) {
        // Verifica se o usuário existe
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado com o ID: " + usuarioId));

        // Verifica se o endereço do usuário já existe
        Endereco endereco = enderecoRepository.findByUsuario(usuario)
                .orElseThrow(() -> new IllegalArgumentException("Endereço não encontrado para o usuário com ID: " + usuarioId));

        // Atualiza os dados do endereço com as novas informações
        endereco.setRua(enderecoDTO.getRua());
        endereco.setNumero(enderecoDTO.getNumero());
        endereco.setComplemento(enderecoDTO.getComplemento());
        endereco.setCodigoPostal(enderecoDTO.getCodigoPostal());
        endereco.setBairro(enderecoDTO.getBairro());
        endereco.setCidade(enderecoDTO.getCidade());
        endereco.setEstado(enderecoDTO.getEstado());

        // Salva o endereço atualizado no banco
        return enderecoRepository.save(endereco);
    }

    // Obter endereço pelo ID do usuário
    @Transactional
    public Endereco obterEnderecoPorUsuarioId(Long usuarioId) {
        // Verifica se o usuário existe
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado com o ID: " + usuarioId));

        // Retorna o endereço associado a esse usuário
        return enderecoRepository.findByUsuario(usuario)
                .orElseThrow(() -> new IllegalArgumentException("Endereço não encontrado para o usuário com ID: " + usuarioId));
    }

    // Deletar endereço do usuário
    @Transactional
    public void deletarEndereco(Long usuarioId) {
        // Verifica se o usuário existe
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado com o ID: " + usuarioId));

        // Verifica se o endereço existe para o usuário
        Endereco endereco = enderecoRepository.findByUsuario(usuario)
                .orElseThrow(() -> new IllegalArgumentException("Endereço não encontrado para o usuário com ID: " + usuarioId));

        // Deleta o endereço
        enderecoRepository.delete(endereco);
    }

    // Buscar endereço pelo CPF do usuário
    public Endereco buscarEnderecoPorCpfUsuario(String cpf) {
        // Primeiro, buscamos o usuário pelo CPF
        Usuario usuario = usuarioRepository.findByCpf(cpf)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado com o CPF: " + cpf));

        // Agora, encontramos o endereço do usuário
        Optional<Endereco> endereco = enderecoRepository.findByUsuarioCpf(cpf);

        // Retorna o endereço, ou lança exceção caso não encontre
        return endereco.orElseThrow(() -> new IllegalArgumentException("Endereço não encontrado para o usuário com CPF: " + cpf));
    }
}
