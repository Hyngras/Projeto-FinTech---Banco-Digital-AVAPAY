package com.avapay.dto;

public class CadastroPixDTO {

    private Long pixId;
    private String chavePix;
    private String tipoChavePix;
    private Long contaId;

    // Getters e Setters
    public Long getPixId() {
        return pixId;
    }

    public void setPixId(Long pixId) {
        this.pixId = pixId;
    }

    public String getChavePix() {
        return chavePix;
    }

    public void setChavePix(String chavePix) {
        this.chavePix = chavePix;
    }

    public String getTipoChavePix() {
        return tipoChavePix;
    }

    public void setTipoChavePix(String tipoChavePix) {
        this.tipoChavePix = tipoChavePix;
    }

    public Long getContaId() {
        return contaId;
    }

    public void setContaId(Long contaId) {
        this.contaId = contaId;
    }
} 
