package com.avapay.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.avapay.model.TipoUsuario;
import com.avapay.model.Usuario;
import com.avapay.repository.TipoUsuarioRepository;
import com.avapay.repository.UsuarioRepository;

import jakarta.transaction.Transactional;

@Service
public class CustomService implements UserDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(CustomService.class);

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private TipoUsuarioRepository tipoUsuarioRepository;

    private final PasswordEncoder passwordEncoder;

    @Autowired
    public CustomService() {
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    public String encodePassword(String password) {
        return passwordEncoder.encode(password);
    }

    public boolean validatePassword(String rawPassword, String encodedPassword) {
        return passwordEncoder.matches(rawPassword, encodedPassword);
    }

    public Usuario findUsuarioByEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    public Usuario findUsuarioById(Long id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    @Transactional
    public void saveUsuario(Usuario usuario, String nomeTipo) {

        if (nomeTipo == null || nomeTipo.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do tipo de usuário não pode ser nulo ou vazio!");
        }

        usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
        usuario.setAtivo(true);

        Optional<TipoUsuario> tipoUsuarioOpt = tipoUsuarioRepository.findByNomeTipoUsuario(nomeTipo);

        TipoUsuario tipoUsuario = tipoUsuarioOpt.orElseGet(() -> {
            TipoUsuario novoTipo = new TipoUsuario();
            novoTipo.setNomeTipoUsuario(nomeTipo);
            return tipoUsuarioRepository.save(novoTipo);
        });

        Set<TipoUsuario> tiposUsuario = new HashSet<>();
        tiposUsuario.add(tipoUsuario);
        usuario.setTiposUsuario(tiposUsuario);

        usuarioRepository.save(usuario);
        logger.info("Usuário salvo com sucesso: {}", usuario.getEmail());
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Usuario usuario = usuarioRepository.findByEmail(email);

        if (usuario == null) {
            throw new UsernameNotFoundException("Usuário com o email '" + email + "' não foi encontrado.");
        }

        return new org.springframework.security.core.userdetails.User(
                usuario.getEmail(),
                usuario.getSenha(),
                getUsuarioAuthority(usuario.getTiposUsuario())
        );
    }

    private List<GrantedAuthority> getUsuarioAuthority(Set<TipoUsuario> tiposUsuario) {

        Set<GrantedAuthority> authorities = new HashSet<>();

        tiposUsuario.forEach((tipoUsuario) -> {
            authorities.add(new SimpleGrantedAuthority("ROLE_" + tipoUsuario.getNomeTipoUsuario()));
        });

        return new ArrayList<>(authorities);
    }
}
