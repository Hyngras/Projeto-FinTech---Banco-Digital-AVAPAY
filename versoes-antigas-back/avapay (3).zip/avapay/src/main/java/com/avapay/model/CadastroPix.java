package com.avapay.model;

import jakarta.persistence.*;

@Entity
@Table(name = "CadastroPix")  // Alterado para camel case, seguindo o padrão do projeto base
public class CadastroPix {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pix_id")  // Mantido conforme o projeto base
    private Long pixId;

    @Column(name = "pix_type", nullable = false, length = 50)  // Mantido conforme o projeto base
    private String pixType;

    @Column(name = "pix", length = 255)  // Alterado de 'chavePix' para 'pix' para manter o padrão
    private String pix;

    @ManyToOne
    @JoinColumn(name = "accountId", nullable = false)  // Alterado de 'id_conta' para 'accountId' para manter o padrão
    private ContaBancaria contaBancaria; 

    // Getters e Setters
    public Long getPixId() {
        return pixId;
    }

    public void setPixId(Long pixId) {
        this.pixId = pixId;
    }

    public String getPixType() {
        return pixType;
    }

    public void setPixType(String pixType) {
        this.pixType = pixType;
    }

    public String getPix() {
        return pix;
    }

    public void setPix(String pix) {
        this.pix = pix;
    }

    public ContaBancaria getContaBancaria() {
        return contaBancaria;
    }

    public void setContaBancaria(ContaBancaria contaBancaria) {
        this.contaBancaria = contaBancaria;
    }
}
