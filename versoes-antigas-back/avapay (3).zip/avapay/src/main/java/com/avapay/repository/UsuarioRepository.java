package com.avapay.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.avapay.model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    
    // Buscar usuário pelo email
    Usuario findByEmail(String email);
    
    // Verificar se existe um usuário com o CPF informado
    boolean existsByCpf(String cpf);
    
    // Buscar lista de usuários pelo nome
    List<Usuario> findByNome(String nome);
    
    // Buscar usuário pelo ID (retornando Optional)
    Optional<Usuario> findById(Long id);  // Este método já está presente no JpaRepository, mas incluído aqui para clareza
    
    // Buscar usuário pelo CPF (retornando Optional)
    Optional<Usuario> findByCpf(String cpf);
    
    // Buscar usuário pelo ID diretamente (não recomendado, mas mantido conforme o projeto base)
    Usuario findUsuarioById(Usuario id);
}
