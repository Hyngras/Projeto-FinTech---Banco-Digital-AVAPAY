package com.avapay;

import java.util.Optional;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.avapay.model.TipoUsuario;
import com.avapay.repository.TipoUsuarioRepository;

@SpringBootApplication
public class AvapayApplication {

    public static void main(String[] args) {
        SpringApplication.run(AvapayApplication.class, args);
    }

    @Bean
    CommandLineRunner init(TipoUsuarioRepository tipoUsuarioRepository) {
        return args -> {
            // Verifica se o tipo de usuário "ADMIN" já existe
            Optional<TipoUsuario> adminTipo = tipoUsuarioRepository.findByNomeTipoUsuario("ADMIN");
            if (adminTipo.isEmpty()) {
                TipoUsuario novoAdminTipo = new TipoUsuario();
                novoAdminTipo.setNomeTipoUsuario("ADMIN");
                tipoUsuarioRepository.save(novoAdminTipo);
                System.out.println("Tipo de usuário 'ADMIN' criado com sucesso!");
            } else {
                System.out.println("Tipo de usuário 'ADMIN' já existe.");
            }

            // Verifica se o tipo de usuário "USER" já existe
            Optional<TipoUsuario> userTipo = tipoUsuarioRepository.findByNomeTipoUsuario("USER");
            if (userTipo.isEmpty()) {
                TipoUsuario novoUserTipo = new TipoUsuario();
                novoUserTipo.setNomeTipoUsuario("USER");
                tipoUsuarioRepository.save(novoUserTipo);
                System.out.println("Tipo de usuário 'USER' criado com sucesso!");
            } else {
                System.out.println("Tipo de usuário 'USER' já existe.");
            }
        };
    }
}
