package com.avapay.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.avapay.model.ContaBancaria;
import com.avapay.model.Transacoes;

public interface TransacoesRepository extends JpaRepository<Transacoes, Long> {

    // Buscar transações pela conta de origem
    List<Transacoes> findByContaOrigem(ContaBancaria contaOrigem);
    
    // Buscar transações pela conta de destino (adicionado para completar a lógica)
    List<Transacoes> findByContaDestino(ContaBancaria contaDestino);
}
