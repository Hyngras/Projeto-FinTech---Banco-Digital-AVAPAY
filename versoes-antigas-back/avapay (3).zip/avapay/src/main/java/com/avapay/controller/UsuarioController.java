package com.avapay.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.avapay.dto.CriacaoClienteDTO;
import com.avapay.dto.UsuarioUpdateDTO;
import com.avapay.model.Usuario;
import com.avapay.service.UsuarioService;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    // Criar um novo usuário com endereço e conta bancária
    @PostMapping("/criarUsuario")
    public ResponseEntity<Usuario> criarUsuario(@RequestBody CriacaoClienteDTO cadastroClienteDTO) {
        Usuario novoUsuario = usuarioService.criarUsuario(cadastroClienteDTO);
        return new ResponseEntity<>(novoUsuario, HttpStatus.CREATED);
    }

    // Atualizar usuário
    @PutMapping("/atualizarUsuario/{usuarioId}")
    public ResponseEntity<Usuario> atualizarUsuario(@PathVariable Long usuarioId,
                                                    @RequestBody UsuarioUpdateDTO atualizacaoUsuarioDTO) {
        Usuario usuarioAtualizado = usuarioService.atualizarUsuario(usuarioId, atualizacaoUsuarioDTO);
        return ResponseEntity.ok(usuarioAtualizado);
    }

    // Buscar todos os usuários
    @GetMapping("/buscarTodos")
    public ResponseEntity<List<Usuario>> buscarTodosUsuarios() {
        List<Usuario> usuarios = usuarioService.buscarTodos();
        return ResponseEntity.ok(usuarios);
    }

    // Buscar usuário por ID
    @GetMapping("/buscarPorId/{id}")
    public ResponseEntity<Usuario> buscarUsuarioPorId(@PathVariable Long id) {
        Optional<Usuario> usuario = usuarioService.buscarPorId(id);
        return usuario.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    // Buscar usuário por CPF
    @GetMapping("/buscarPorCpf/{cpf}")
    public ResponseEntity<Usuario> buscarUsuarioPorCpf(@PathVariable String cpf) {
        Optional<Usuario> usuario = usuarioService.buscarPorCpf(cpf);
        return usuario.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).body(null));
    }

    // Deletar usuário
    @DeleteMapping("/deletar/{usuarioId}")
    public ResponseEntity<String> deletarUsuario(@PathVariable Long usuarioId) {
        usuarioService.deletarUsuario(usuarioId);
        return ResponseEntity.ok("Usuário deletado com sucesso!");
    }
}
