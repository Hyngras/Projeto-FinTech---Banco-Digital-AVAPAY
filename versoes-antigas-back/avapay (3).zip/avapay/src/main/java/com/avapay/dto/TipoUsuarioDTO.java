package com.avapay.dto;

public class TipoUsuarioDTO {

    private Long tipoUsuarioId;
    private String nomeTipoUsuario;  // Alterado para manter consistência com outros campos do projeto

    // Getters e Setters
    public Long getTipoUsuarioId() {
        return tipoUsuarioId;
    }

    public void setTipoUsuarioId(Long tipoUsuarioId) {
        this.tipoUsuarioId = tipoUsuarioId;
    }

    public String getNomeTipoUsuario() {
        return nomeTipoUsuario;
    }

    public void setNomeTipoUsuario(String nomeTipoUsuario) {
        this.nomeTipoUsuario = nomeTipoUsuario;
    }
}
