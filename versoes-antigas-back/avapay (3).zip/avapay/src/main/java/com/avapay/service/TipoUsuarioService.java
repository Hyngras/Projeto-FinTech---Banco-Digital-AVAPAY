package com.avapay.service;

import com.avapay.model.TipoUsuario;
import com.avapay.repository.TipoUsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class TipoUsuarioService {

    private static final Logger logger = LoggerFactory.getLogger(TipoUsuarioService.class);

    @Autowired
    private TipoUsuarioRepository tipoUsuarioRepository;

    // Método para encontrar tipos de usuário por IDs
    public Set<TipoUsuario> findTiposUsuarioByIds(Set<Long> tipoUsuarioIds) {
        return Set.copyOf(tipoUsuarioRepository.findAllById(tipoUsuarioIds));
    }

    // Método para buscar todos os tipos de usuário
    public List<TipoUsuario> findAllTiposUsuario() {
        return tipoUsuarioRepository.findAll();
    }

    // Método para buscar um tipo de usuário pelo seu nome
    public Optional<TipoUsuario> findTipoUsuarioByNome(String nomeTipo) {
        return tipoUsuarioRepository.findByNomeTipoUsuario(nomeTipo);
    }

    // Método para criar um novo tipo de usuário
    public TipoUsuario createTipoUsuario(TipoUsuario tipoUsuario) {
        if (tipoUsuario.getNomeTipoUsuario() == null || tipoUsuario.getNomeTipoUsuario().trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do tipo de usuário não pode ser nulo ou vazio!");
        }
        TipoUsuario savedTipoUsuario = tipoUsuarioRepository.save(tipoUsuario);
        logger.info("Tipo de usuário criado com sucesso: {}", savedTipoUsuario.getNomeTipoUsuario());
        return savedTipoUsuario;
    }

    // Método para atualizar um tipo de usuário existente
    public TipoUsuario updateTipoUsuario(Long tipoUsuarioId, TipoUsuario tipoUsuarioAtualizado) {
        if (tipoUsuarioRepository.existsById(tipoUsuarioId)) {
            tipoUsuarioAtualizado.setId(tipoUsuarioId);
            TipoUsuario updatedTipoUsuario = tipoUsuarioRepository.save(tipoUsuarioAtualizado);
            logger.info("Tipo de usuário atualizado com sucesso: {}", updatedTipoUsuario.getNomeTipoUsuario());
            return updatedTipoUsuario;
        }
        throw new IllegalArgumentException("Tipo de usuário com ID " + tipoUsuarioId + " não encontrado.");
    }

    // Método para deletar um tipo de usuário
    public void deleteTipoUsuario(Long tipoUsuarioId) {
        if (tipoUsuarioRepository.existsById(tipoUsuarioId)) {
            tipoUsuarioRepository.deleteById(tipoUsuarioId);
            logger.info("Tipo de usuário com ID {} deletado com sucesso.", tipoUsuarioId);
        } else {
            throw new IllegalArgumentException("Tipo de usuário com ID " + tipoUsuarioId + " não encontrado para exclusão.");
        }
    }
}
