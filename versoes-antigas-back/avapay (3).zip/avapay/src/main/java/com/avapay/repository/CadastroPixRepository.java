package com.avapay.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avapay.model.ContaBancaria;
import com.avapay.model.CadastroPix;

@Repository
public interface CadastroPixRepository extends JpaRepository<CadastroPix, Long> {

    // Buscar registros de Pix por conta bancária
    List<CadastroPix> findByContaBancaria(ContaBancaria contaBancaria);
    
    // Buscar um registro de Pix pela chave Pix (adicional para complementar a lógica)
    Optional<CadastroPix> findByPix(String pix);
}
