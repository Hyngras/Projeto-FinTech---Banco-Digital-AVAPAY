package com.avapay.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class UsuarioDTO {

    private Long usuarioId;
    private String nome;
    private String cpf;
    private String email;
    private String telefone;
    private LocalDateTime dataCriacao;
    private long tipoUsuarioId;  // Caso seja necessário para um único tipo de usuário
    private String senha;
    private boolean ativo;

    private ContaBancariaDTO conta;
    private EnderecoDTO endereco;

    // Lista para múltiplos tipos de usuário (equivalente a múltiplos roles)
    private List<Long> tiposUsuarioIds;
}
