package com.avapay.controller;

import com.avapay.dto.EnderecoDTO;
import com.avapay.model.Endereco;
import com.avapay.service.EnderecoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/enderecos")
public class EnderecoController {

    @Autowired
    private EnderecoService enderecoService;

    // Endpoint para criar ou atualizar um endereço para o usuário
    @PostMapping("/atualizarOuCriar/{usuarioId}")
    public ResponseEntity<Endereco> atualizarOuCriarEndereco(@PathVariable Long usuarioId, @RequestBody EnderecoDTO enderecoDTO) {
        Endereco endereco = enderecoService.atualizarEnderecoUsuario(usuarioId, enderecoDTO);
        return ResponseEntity.ok(endereco);
    }

    // Endpoint para obter o endereço de um usuário pelo ID
    @GetMapping("/obter/{usuarioId}")
    public ResponseEntity<Endereco> obterEndereco(@PathVariable Long usuarioId) {
        Endereco endereco = enderecoService.obterEnderecoPorUsuarioId(usuarioId);
        return ResponseEntity.ok(endereco);
    }

    // Endpoint para deletar o endereço de um usuário
    @DeleteMapping("/deletar/{usuarioId}")
    public ResponseEntity<String> deletarEndereco(@PathVariable Long usuarioId) {
        enderecoService.deletarEndereco(usuarioId);
        return ResponseEntity.ok("Endereço deletado com sucesso!");
    }

    // Endpoint para buscar o endereço de um usuário pelo CPF
    @GetMapping("/buscarPorCpf/{cpf}")
    public ResponseEntity<EnderecoDTO> buscarEnderecoPorCpf(@PathVariable String cpf) {
        Endereco endereco = enderecoService.buscarEnderecoPorUsuarioCpf(cpf);

        // Mapear para o DTO
        EnderecoDTO enderecoDTO = new EnderecoDTO();
        enderecoDTO.setRua(endereco.getRua());
        enderecoDTO.setNumero(endereco.getNumero());
        enderecoDTO.setComplemento(endereco.getComplemento());
        enderecoDTO.setCep(endereco.getCep());
        enderecoDTO.setBairro(endereco.getBairro());
        enderecoDTO.setCidade(endereco.getCidade());
        enderecoDTO.setEstado(endereco.getEstado());

        return ResponseEntity.ok(enderecoDTO);
    }
}
