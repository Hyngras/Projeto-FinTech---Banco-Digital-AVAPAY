package com.avapay.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.avapay.model.ContaBancaria;
import com.avapay.service.ContaBancariaService;

@RestController
@RequestMapping("/api/contas")
public class ContaBancariaController {

    @Autowired
    private ContaBancariaService contaBancariaService;

    // Obter conta por ID
    @GetMapping("/{contaId}")
    public Optional<ContaBancaria> obterContaPorId(@PathVariable Long contaId) {
        return contaBancariaService.getContaById(contaId);
    }

    // Obter conta por número da conta
    @GetMapping("/numero/{numeroConta}")
    public Optional<ContaBancaria> obterContaPorNumero(@PathVariable String numeroConta) {
        return contaBancariaService.getContaByNumeroConta(numeroConta);
    }

    // Obter conta por CPF do cliente
    @GetMapping("/cpf/{cpfCliente}")
    public Optional<ContaBancaria> obterContaPorCpf(@PathVariable String cpfCliente) {
        return contaBancariaService.getContaByCpfCliente(cpfCliente);
    }

    // Deletar conta
    @DeleteMapping("/{contaId}")
    public boolean deletarConta(@PathVariable Long contaId) {
        return contaBancariaService.deletarConta(contaId);
    }
}
