package com.avapay.service;

import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.avapay.model.ContaBancaria;
import com.avapay.repository.ContaBancariaRepository;
import com.avapay.repository.UsuarioRepository;

@Service
public class ContaBancariaService {

    @Autowired
    private ContaBancariaRepository contaBancariaRepository;

    @Autowired
    private UsuarioRepository usuarioRepository; 

    // Método para gerar número de conta único
    public String gerarNumeroConta() {
        int min = 1000000;
        int max = 9999999;

        Random random = new Random();
        int numeroAleatorio;

        do {
            numeroAleatorio = random.nextInt((max - min) + 1) + min;
        } while (contaBancariaRepository.findByNumeroConta(String.valueOf(numeroAleatorio)).isPresent());

        return String.valueOf(numeroAleatorio);
    }

    // Obter conta bancária por ID
    public Optional<ContaBancaria> obterContaPorId(Long contaId) {
        return contaBancariaRepository.findById(contaId);
    }

    // Obter conta bancária por número da conta
    public Optional<ContaBancaria> obterContaPorNumero(String numeroConta) {
        return contaBancariaRepository.findByNumeroConta(numeroConta);
    }

    // Obter conta bancária pelo CPF do cliente
    public Optional<ContaBancaria> obterContaPorCpfCliente(String cpfCliente) {
        return contaBancariaRepository.findByCpfCliente(cpfCliente);
    }

    // Deletar conta bancária
    public boolean deletarConta(Long contaId) {
        if (contaBancariaRepository.existsById(contaId)) {
            contaBancariaRepository.deleteById(contaId);
            return true;
        }
        return false;
    }
}
