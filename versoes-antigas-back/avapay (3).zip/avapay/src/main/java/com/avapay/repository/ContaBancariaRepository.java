package com.avapay.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.avapay.model.ContaBancaria;

@Repository
public interface ContaBancariaRepository extends JpaRepository<ContaBancaria, Long> {

    // Buscar conta pelo número
    Optional<ContaBancaria> findByNumeroConta(String numeroConta);
    
    // Verificar se existe uma conta com o número informado
    boolean existsByNumeroConta(String numeroConta);
    
    // Buscar conta pelo CPF do cliente
    Optional<ContaBancaria> findByCpfCliente(String cpfCliente);
}
