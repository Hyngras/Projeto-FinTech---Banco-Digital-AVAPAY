package com.avapay.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.avapay.dto.CriacaoClienteDTO;
import com.avapay.dto.EnderecoDTO;
import com.avapay.model.Endereco;
import com.avapay.model.Usuario;
import com.avapay.repository.ContaBancariaRepository;
import com.avapay.repository.EnderecoRepository;
import com.avapay.repository.TipoUsuarioRepository;
import com.avapay.repository.UsuarioRepository;

import jakarta.transaction.Transactional;

@Service
public class UsuarioService {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private TipoUsuarioRepository tipoUsuarioRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private EnderecoRepository enderecoRepository;

    @Autowired
    private ContaBancariaRepository contaBancariaRepository;

    @Autowired
    private ContaBancariaService contaBancariaService;

    @Autowired
    private EnderecoService enderecoService;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    // Criar um novo usuário com endereço
    @Transactional
    public Usuario criarUsuario(CriacaoClienteDTO usuarioCriacaoDTO) {
        // Criar o usuário
        Usuario usuario = new Usuario();
        usuario.setNome(usuarioCriacaoDTO.getNome());
        usuario.setCpf(usuarioCriacaoDTO.getCpf());
        usuario.setEmail(usuarioCriacaoDTO.getEmail());
        usuario.setTelefone(usuarioCriacaoDTO.getTelefone());
        usuario.setSenha(passwordEncoder.encode(usuarioCriacaoDTO.getSenha())); // Criptografando a senha
        usuario.setDataCriacao(LocalDateTime.now());
        usuario.setAtivo(true);

        usuario = usuarioRepository.save(usuario);

        // Criar o endereço associado ao usuário
        EnderecoDTO enderecoDTO = new EnderecoDTO();
        enderecoDTO.setRua(usuarioCriacaoDTO.getRua());
        enderecoDTO.setNumero(usuarioCriacaoDTO.getNumero());
        enderecoDTO.setComplemento(usuarioCriacaoDTO.getComplemento());
        enderecoDTO.setCodigoPostal(usuarioCriacaoDTO.getCodigoPostal());
        enderecoDTO.setBairro(usuarioCriacaoDTO.getBairro());
        enderecoDTO.setCidade(usuarioCriacaoDTO.getCidade());
        enderecoDTO.setEstado(usuarioCriacaoDTO.getEstado());

        Endereco endereco = new Endereco();
        endereco.setRua(enderecoDTO.getRua());
        endereco.setNumero(enderecoDTO.getNumero());
        endereco.setComplemento(enderecoDTO.getComplemento());
        endereco.setCodigoPostal(enderecoDTO.getCodigoPostal());
        endereco.setBairro(enderecoDTO.getBairro());
        endereco.setCidade(enderecoDTO.getCidade());
        endereco.setEstado(enderecoDTO.getEstado());
        endereco.setUsuario(usuario);

        endereco = enderecoRepository.save(endereco);
        usuarioRepository.save(usuario);

        return usuario;
    }

    // Atualizar dados do usuário
    @Transactional
    public Usuario atualizarUsuario(Long usuarioId, CriacaoClienteDTO usuarioAtualizacaoDTO) {
        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new IllegalArgumentException("Usuário não encontrado com o ID: " + usuarioId));

        usuario.setNome(usuarioAtualizacaoDTO.getNome());
        usuario.setEmail(usuarioAtualizacaoDTO.getEmail());
        usuario.setTelefone(usuarioAtualizacaoDTO.getTelefone());

        return usuarioRepository.save(usuario);
    }

    // Deletar usuário
    public void deletarUsuario(Long usuarioId) {
        Optional<Usuario> usuarioOptional = usuarioRepository.findById(usuarioId);
        if (usuarioOptional.isEmpty()) {
            throw new IllegalArgumentException("Usuário não encontrado com o ID: " + usuarioId);
        }
        usuarioRepository.deleteById(usuarioId);
    }

    // Buscar todos os usuários
    public List<Usuario> buscarTodos() {
        return usuarioRepository.findAll();
    }

    // Buscar usuário por ID
    public Optional<Usuario> buscarPorId(Long id) {
        return usuarioRepository.findById(id);
    }

    // Buscar usuário por CPF
    public Optional<Usuario> buscarPorCpf(String cpf) {
        return usuarioRepository.findByCpf(cpf);
    }
}
