package com.avapay.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.avapay.model.Endereco;
import com.avapay.model.Usuario;

public interface EnderecoRepository extends JpaRepository<Endereco, Long> {

    // Buscar endereço pelo nome do usuário
    Endereco findByUsuarioNome(String nomeUsuario);
    
    // Buscar endereço pelo usuário
    Optional<Endereco> findByUsuario(Usuario usuario);
    
    // Buscar endereço pelo CPF do usuário
    Optional<Endereco> findByUsuarioCpf(String cpf);
}
