package com.avapay.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.avapay.dto.LoginDTO;
import com.avapay.dto.RegistroDTO;
import com.avapay.model.Usuario;
import com.avapay.service.CustomService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/usuarios")
public class AuthController {

    @Autowired
    private CustomService usuarioService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDTO loginDto) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                    		loginDto.getEmail(),
                    		loginDto.getSenha()
                    )
            );

            SecurityContextHolder.getContext().setAuthentication(authentication);

            Map<String, String> response = new HashMap<>();
            response.put("message", "Login feito com sucesso");
            return ResponseEntity.ok(response);

        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Falhou o login: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> createNewUsuario(
            @Valid @RequestBody RegistroDTO registroDto,
            BindingResult bindingResult,
            @RequestParam String nomeTipo) {

        Usuario usuarioExists = usuarioService.findUsuarioByEmail(registroDto.getEmail());

        if (usuarioExists != null) {
            bindingResult.rejectValue("email", "error.usuario", "Já existe um usuário cadastrado com este email!");
        }

        if (bindingResult.hasErrors()) {
            Map<String, String> errors = new HashMap<>();
            for (FieldError error : bindingResult.getFieldErrors()) {
                errors.put(error.getField(), error.getDefaultMessage());
            }
            return ResponseEntity.badRequest().body(errors);
        }

        Usuario usuario = new Usuario();
        usuario.setEmail(registroDto.getEmail());
        usuario.setSenha(registroDto.getSenha());
        usuario.setNome(registroDto.getNome());
        usuario.setCpf(registroDto.getCpf());
        usuario.setDataCriacao(registroDto.getDataCriacao());
        usuario.setTelefone(registroDto.getTelefone());

        usuarioService.saveUsuario(usuario, nomeTipo);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Usuário cadastrado com sucesso!");

        return ResponseEntity.ok(response);
    }

    @PostMapping("/logout")
    public ResponseEntity<Void> logout(HttpServletRequest request, HttpServletResponse response) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null) {
            new SecurityContextLogoutHandler().logout(request, response, authentication);
            System.out.println("Logout efetuado com sucesso para o usuário: " + authentication.getName());
        } else {
            System.out.println("Tentativa de logout sem usuário autenticado!");
        }

        return ResponseEntity.noContent().build();
    }

    @GetMapping("/current-user")
    public String getLoggedInUsuario() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getName();
    }
}
