package com.avapay.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.avapay.dto.CadastroPixDTO;
import com.avapay.model.CadastroPix;
import com.avapay.model.ContaBancaria;  // Ajustar conforme o nome da sua entidade de conta
import com.avapay.repository.CadastroPixRepository;
import com.avapay.repository.ContaBancariaRepository;  // Repositório para buscar a conta

@Service
public class CadastroPixService {

    @Autowired
    private CadastroPixRepository cadastroPixRepository;

    @Autowired
    private ContaBancariaRepository contaBancariaRepository;  // Injetando o repositório da conta

    // Listar todos os Cadastros de Pix
    public List<CadastroPix> listarTodos() {
        return cadastroPixRepository.findAll();
    }

    // Buscar Cadastro de Pix por ID
    public CadastroPix buscarPorId(Long id) {
        return cadastroPixRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("CadastroPix não encontrado com o ID: " + id));
    }

    // Criar um novo Cadastro de Pix
    public CadastroPix criarCadastroPix(CadastroPixDTO cadastroPixDto) {
        CadastroPix cadastroPix = new CadastroPix();
        cadastroPix.setChavePix(cadastroPixDto.getChavePix());
        cadastroPix.setTipoPix(cadastroPixDto.getTipoChavePix());

        // Buscar e associar a conta
        ContaBancaria conta = contaBancariaRepository.findById(cadastroPixDto.getContaId())
            .orElseThrow(() -> new RuntimeException("Conta não encontrada com o ID: " + cadastroPixDto.getContaId()));

        cadastroPix.setContaBancaria(conta);  // Associa a conta ao cadastro Pix

        return cadastroPixRepository.save(cadastroPix);
    }

    // Atualizar um Cadastro de Pix
    public CadastroPix atualizarCadastroPix(Long id, CadastroPixDTO cadastroPixDto) {
        CadastroPix cadastroPixExistente = cadastroPixRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("CadastroPix não encontrado com o ID: " + id));

        cadastroPixExistente.setChavePix(cadastroPixDto.getChavePix());
        cadastroPixExistente.setTipoPix(cadastroPixDto.getTipoChavePix());

        // Atualizar a conta, se necessário
        if (cadastroPixDto.getContaId() != null) {
            ContaBancaria conta = contaBancariaRepository.findById(cadastroPixDto.getContaId())
                .orElseThrow(() -> new RuntimeException("Conta não encontrada com o ID: " + cadastroPixDto.getContaId()));

            cadastroPixExistente.setContaBancaria(conta);
        }

        return cadastroPixRepository.save(cadastroPixExistente);
    }

    // Deletar um Cadastro de Pix
    public void deletarCadastroPix(Long id) {
        cadastroPixRepository.deleteById(id);
    }
}
