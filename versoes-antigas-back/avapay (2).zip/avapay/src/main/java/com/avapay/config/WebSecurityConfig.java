/*package com.avapay.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.avapay.service.CustomService;

import jakarta.servlet.http.HttpServletResponse;
 
@Configuration
@EnableWebSecurity
public class WebSecurityConfig {
 
    @Autowired
    private CustomService userDetailsService;
 
    // Bean para codificador de senha (bcrypt)
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
 
    // Configuração do AuthenticationManager
    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder =
            http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder
            .userDetailsService(userDetailsService)
            .passwordEncoder(passwordEncoder()); // Usa o método passwordEncoder() para obter o bean
        return authenticationManagerBuilder.build();
    }
 
    // Configuração de CORS
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
 
        config.setAllowedOrigins(Arrays.asList("http://localhost:4200", "http://localhost:8080"));
        config.setAllowedMethods(Arrays.asList(
            HttpMethod.GET.name(),
            HttpMethod.POST.name(),
            HttpMethod.PUT.name(),
            HttpMethod.DELETE.name(),
            HttpMethod.OPTIONS.name()
        ));
        config.setAllowedHeaders(Arrays.asList("Authorization", "Cache-Control", "Content-Type", 
        		"Access-Control-Allow-Headers", "*"));
        config.setExposedHeaders(Arrays.asList("Authorization"));
        config.setAllowCredentials(true);
        config.setMaxAge(3600L);
        source.registerCorsConfiguration("/**", config);
 
        return source;
    }
 
    // Configuração da cadeia de filtros de segurança //Usuario
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .authorizeHttpRequests(auth -> auth
                // Libera o acesso total ao Swagger
                .requestMatchers(
                    "/swagger-ui/**", 
                    "/v3/api-docs/**", 
                    "/swagger-ui.html", 
                    "/swagger-resources/**", 
                    "/webjars/**"
                ).permitAll()

                // Libera OPTIONS (necessário para CORS e Swagger funcionar corretamente)
                .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()

                // Libera o cadastro e login de usuários
                .requestMatchers("/api/usuarios/register", "/api/usuarios/login").permitAll()

                // Libera todos os métodos para o Cadastro Pix
                .requestMatchers("/api/cadastroPix/**").permitAll()

                // Libera todos os métodos para as Transações
                .requestMatchers("/api/transacoes/**").permitAll()

                // Mantém restrições para outras APIs específicas, se necessário
                .requestMatchers(HttpMethod.POST, "/api/notes/**").hasAnyAuthority("ROLE_USER", "ROLE_ADMIN")
                .requestMatchers(HttpMethod.PUT, "/createCadastroPix**").hasAuthority("ROLE_ADMIN")
                .requestMatchers(HttpMethod.DELETE, "/api/deleteCadastroPix/{id}**").hasAuthority("ROLE_ADMIN")

                // Exige autenticação para qualquer outro endpoint não especificado
                .anyRequest().authenticated()
            )
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.ALWAYS)
            )
            .logout(logout -> logout
                .logoutRequestMatcher(new org.springframework.security.web.util.matcher.AntPathRequestMatcher("/logout"))
                .logoutSuccessUrl("/")
                .invalidateHttpSession(true)
                .deleteCookies("JSESSIONID")
            )
            .httpBasic(httpBasic -> httpBasic
                .authenticationEntryPoint((request, response, authException) -> {
                    response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
                })
            )
            .csrf(csrf -> csrf.disable());

        return http.build();
   }
}
*/

package com.avapay.config; 

  

import java.util.Arrays; 

  

import org.springframework.beans.factory.annotation.Autowired; 

import org.springframework.context.annotation.Bean; 

import org.springframework.context.annotation.Configuration; 

import org.springframework.http.HttpMethod; 

import org.springframework.security.authentication.AuthenticationManager; 

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder; 

import org.springframework.security.config.annotation.web.builders.HttpSecurity; 

import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity; 

import org.springframework.security.config.http.SessionCreationPolicy; 

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; 

import org.springframework.security.crypto.password.PasswordEncoder; 

import org.springframework.security.web.SecurityFilterChain; 

import org.springframework.web.cors.CorsConfiguration; 

import org.springframework.web.cors.CorsConfigurationSource; 

import org.springframework.web.cors.UrlBasedCorsConfigurationSource; 

  

import com.avapay.service.CustomService; 

  

import jakarta.servlet.http.HttpServletResponse; 

  

@Configuration 

@EnableWebSecurity 

public class WebSecurityConfig { 

  

    @Autowired 

    private CustomService userDetailsService; 

  

    // Bean para codificador de senha (bcrypt) 

    @Bean 

    public PasswordEncoder passwordEncoder() { 

        return new BCryptPasswordEncoder(); 

    } 

  

    // Configuração do AuthenticationManager 

    @Bean 

    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception { 

        AuthenticationManagerBuilder authenticationManagerBuilder = 

            http.getSharedObject(AuthenticationManagerBuilder.class); 

        authenticationManagerBuilder 

            .userDetailsService(userDetailsService) 

            .passwordEncoder(passwordEncoder()); // Usa o método passwordEncoder() para obter o bean 

        return authenticationManagerBuilder.build(); 

    } 

  

    // Configuração de CORS 

    @Bean 

    public CorsConfigurationSource corsConfigurationSource() { 

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource(); 

        CorsConfiguration config = new CorsConfiguration(); 

  

        config.setAllowedOrigins(Arrays.asList("http://localhost:4200", "http://localhost:8080")); 

        config.setAllowedMethods(Arrays.asList( 

            HttpMethod.GET.name(), 

            HttpMethod.POST.name(), 

            HttpMethod.PUT.name(), 

            HttpMethod.DELETE.name(), 

            HttpMethod.OPTIONS.name() 

        )); 

        config.setAllowedHeaders(Arrays.asList("Authorization", "Cache-Control", "Content-Type",  

        "Access-Control-Allow-Headers", "*")); 

        config.setExposedHeaders(Arrays.asList("Authorization")); 

        config.setAllowCredentials(true); 

        config.setMaxAge(3600L); 

        source.registerCorsConfiguration("/**", config); 

  

        return source; 

    } 

  

    // Configuração da cadeia de filtros de segurança //Usuario 

    @Bean 

    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception { 

        http 

            .cors(cors -> cors.configurationSource(corsConfigurationSource())) 

            .authorizeHttpRequests(auth -> auth 

                // Libera o acesso total ao Swagger 

                .requestMatchers( 

                    "/swagger-ui/**",  

                    "/v3/api-docs/**",  

                    "/swagger-ui.html",  

                    "/swagger-resources/**",  

                    "/webjars/**" 

                ).permitAll() 

  

                // Libera OPTIONS (necessário para CORS e Swagger funcionar corretamente) 

                .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll() 

  

                // Libera o cadastro e login de usuários 

                .requestMatchers("/api/usuarios/register", "/api/usuarios/login").permitAll() 

  

                // Libera todos os métodos para o Cadastro Pix 

                .requestMatchers("/api/cadastroPix/**").permitAll() 

  

                // Libera todos os métodos para as Transações 

                .requestMatchers("/api/transacoes/**").permitAll() 

  

                // Mantém restrições para outras APIs específicas, se necessário 

                .requestMatchers(HttpMethod.POST, "/api/notes/**").hasAnyAuthority("ROLE_USER", "ROLE_ADMIN") 

                .requestMatchers(HttpMethod.PUT, "/createCadastroPix**").hasAuthority("ROLE_ADMIN") 

                .requestMatchers(HttpMethod.DELETE, "/api/deleteCadastroPix/{id}**").hasAuthority("ROLE_ADMIN") 

  

                // Exige autenticação para qualquer outro endpoint não especificado 

                .anyRequest().authenticated() 

            ) 

            .sessionManagement(session -> session 

                .sessionCreationPolicy(SessionCreationPolicy.ALWAYS) 

            ) 

            .logout(logout -> logout 

                .logoutRequestMatcher(new org.springframework.security.web.util.matcher.AntPathRequestMatcher("/logout")) 

                .logoutSuccessUrl("/") 

                .invalidateHttpSession(true) 

                .deleteCookies("JSESSIONID") 

            ) 

            .httpBasic(httpBasic -> httpBasic 

                .authenticationEntryPoint((request, response, authException) -> { 

                    response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized"); 

                }) 

            ) 

            .csrf(csrf -> csrf.disable()); 

  

        return http.build(); 

   } 

} 