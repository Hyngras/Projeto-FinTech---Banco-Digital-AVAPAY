package com.avapay.dto;

import java.time.LocalDateTime;
import java.util.List;

public class UsuarioDTO {

    private Long usuarioId;
    private String nome;
    private String cpf;
    private String email;
    private String telefone;
    private LocalDateTime dataCriacao;
    private long tipoUsuarioId;
    private String senha;
    private boolean ativo;

    private ContaDTO conta;
    private EnderecoDTO endereco;

    private List<Long> tiposUsuarioIds;

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public long getTipoUsuarioId() {
        return tipoUsuarioId;
    }

    public void setTipoUsuarioId(long tipoUsuarioId) {
        this.tipoUsuarioId = tipoUsuarioId;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public ContaDTO getConta() {
        return conta;
    }

    public void setConta(ContaDTO conta) {
        this.conta = conta;
    }

    public EnderecoDTO getEndereco() {
        return endereco;
    }

    public void setEndereco(EnderecoDTO endereco) {
        this.endereco = endereco;
    }

    public List<Long> getTiposUsuarioIds() {
        return tiposUsuarioIds;
    }

    public void setTiposUsuarioIds(List<Long> tiposUsuarioIds) {
        this.tiposUsuarioIds = tiposUsuarioIds;
    }
} 
