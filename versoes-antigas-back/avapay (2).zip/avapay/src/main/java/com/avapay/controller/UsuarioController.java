package com.avapay.controller;

public class UsuarioController {

}
