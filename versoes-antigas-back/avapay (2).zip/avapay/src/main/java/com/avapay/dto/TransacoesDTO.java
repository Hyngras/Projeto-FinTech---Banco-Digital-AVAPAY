package com.avapay.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.avapay.model.Transacoes;

public class TransacoesDTO {

    private Long idTransacao;
    private Long idContaOrigem;
    private Long idContaDestino;
    private String tipoTransacao;
    private BigDecimal valor;
    private LocalDateTime dataHora;
    private String mensagemErro; // Caso haja erro, essa mensagem será retornada

    // Construtor para transação bem-sucedida
    public TransacoesDTO(Transacoes transacao) {
        this.idTransacao = transacao.getIdTransacao();
        this.idContaOrigem = transacao.getContaOrigem() != null ? transacao.getContaOrigem().getIdConta() : null;
        this.idContaDestino = transacao.getContaDestino() != null ? transacao.getContaDestino().getIdConta() : null;
        this.tipoTransacao = transacao.getTipoTransacao();
        this.valor = transacao.getValor();
        this.dataHora = transacao.getDataHora();
    }

    // Construtor para erro (quando algo falha)
    public TransacoesDTO(String mensagemErro) {
        this.mensagemErro = mensagemErro;
    }

    // Getters e Setters
    public Long getIdTransacao() {
        return idTransacao;
    }

    public void setIdTransacao(Long idTransacao) {
        this.idTransacao = idTransacao;
    }

    public Long getIdContaOrigem() {
        return idContaOrigem;
    }

    public void setIdContaOrigem(Long idContaOrigem) {
        this.idContaOrigem = idContaOrigem;
    }

    public Long getIdContaDestino() {
        return idContaDestino;
    }

    public void setIdContaDestino(Long idContaDestino) {
        this.idContaDestino = idContaDestino;
    }

    public String getTipoTransacao() {
        return tipoTransacao;
    }

    public void setTipoTransacao(String tipoTransacao) {
        this.tipoTransacao = tipoTransacao;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public String getMensagemErro() {
        return mensagemErro;
    }

    public void setMensagemErro(String mensagemErro) {
        this.mensagemErro = mensagemErro;
    }
}

