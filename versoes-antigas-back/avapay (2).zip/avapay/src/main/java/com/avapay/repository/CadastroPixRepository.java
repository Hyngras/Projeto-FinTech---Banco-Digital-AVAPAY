package com.avapay.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.avapay.model.ContaBancaria;
import com.avapay.model.CadastroPix;

@Repository
public interface CadastroPixRepository extends JpaRepository<CadastroPix, Long> {

    List<CadastroPix> findByContaBancaria(ContaBancaria contaBancaria);
}
