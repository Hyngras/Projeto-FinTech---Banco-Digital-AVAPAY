package com.avapay.service;

import com.avapay.model.TipoUsuario;
import com.avapay.repository.TipoUsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class TipoUsuarioService {

    @Autowired
    private TipoUsuarioRepository tipoUsuarioRepository;

    // Método para encontrar tipos de usuário por IDs
    public Set<TipoUsuario> findTiposUsuarioByIds(Set<Long> tipoUsuarioIds) {
        return Set.copyOf(tipoUsuarioRepository.findAllById(tipoUsuarioIds));
    }

    // Método para buscar todos os tipos de usuário
    public List<TipoUsuario> findAllTiposUsuario() {
        return tipoUsuarioRepository.findAll();
    }

    // Método para buscar um tipo de usuário pelo seu nome
    public Optional<TipoUsuario> findTipoUsuarioByNome(String nomeTipo) {
        return tipoUsuarioRepository.findByNomeTipo(nomeTipo);
    }

    // Método para criar um novo tipo de usuário
    public TipoUsuario createTipoUsuario(TipoUsuario tipoUsuario) {
        return tipoUsuarioRepository.save(tipoUsuario);
    }

    // Método para atualizar um tipo de usuário existente
    public TipoUsuario updateTipoUsuario(Long tipoUsuarioId, TipoUsuario tipoUsuarioAtualizado) {
        if (tipoUsuarioRepository.existsById(tipoUsuarioId)) {
            tipoUsuarioAtualizado.setId(tipoUsuarioId);
            return tipoUsuarioRepository.save(tipoUsuarioAtualizado);
        }
        return null; // Ou lançar uma exceção personalizada
    }

    // Método para deletar um tipo de usuário
    public void deleteTipoUsuario(Long tipoUsuarioId) {
        if (tipoUsuarioRepository.existsById(tipoUsuarioId)) {
            tipoUsuarioRepository.deleteById(tipoUsuarioId);
        }
    }
} 
