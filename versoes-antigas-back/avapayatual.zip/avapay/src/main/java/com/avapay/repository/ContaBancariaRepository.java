package com.avapay.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.avapay.model.ContaBancaria;

public interface ContaBancariaRepository extends JpaRepository<ContaBancaria, Long> {

    Optional<ContaBancaria> findByNumeroConta(String numeroConta);

    // boolean existsByNumeroConta(String numeroConta);
}
