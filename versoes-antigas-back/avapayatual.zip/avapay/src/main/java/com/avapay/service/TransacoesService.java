/*
package com.avapay.service;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.avapay.model.ContaBancaria;
import com.avapay.model.Transacoes;
import com.avapay.repository.ContaBancariaRepository;
import com.avapay.repository.TransacoesRepository;
import com.avapay.repository.UsuarioRepository;

@Service
public class TransacoesService {

    @Autowired
    private UsuarioRepository UsuarioRepository;

    @Autowired
    private ContaBancariaRepository contaBancariaRepository;

    @Autowired
    private TransacoesRepository transacoesRepository;

    // Realizar depósito
    public ContaBancaria deposito(Long idConta, double valor) {
        ContaBancaria conta = contaBancariaRepository.findById(idConta)
                .orElseThrow(() -> new RuntimeException("Conta não encontrada"));

        conta.setSaldo(conta.getSaldo().add(BigDecimal.valueOf(valor)));
        contaBancariaRepository.save(conta);

        Transacoes transacao = new Transacoes();
        transacao.setValor(BigDecimal.valueOf(valor));
        transacao.setTipoTransacao("DEPOSITO");
        transacao.setContaOrigem(conta);
        transacao.setDataHora(LocalDateTime.now());
        transacoesRepository.save(transacao);

        return conta;
    }

    // Realizar saque
    public ContaBancaria saque(Long idConta, double valor) {
        ContaBancaria conta = contaBancariaRepository.findById(idConta)
                .orElseThrow(() -> new RuntimeException("Conta não encontrada"));

        if (conta.getSaldo().compareTo(BigDecimal.valueOf(valor)) < 0) {
            throw new RuntimeException("Saldo insuficiente");
        }

        conta.setSaldo(conta.getSaldo().subtract(BigDecimal.valueOf(valor)));
        contaBancariaRepository.save(conta);

        Transacoes transacao = new Transacoes();
        transacao.setValor(BigDecimal.valueOf(valor));
        transacao.setTipoTransacao("SAQUE");
        transacao.setContaOrigem(conta);
        transacao.setDataHora(LocalDateTime.now());
        transacoesRepository.save(transacao);

        return conta;
    }

    // Realizar transferência
    public void transferencia(Long idContaOrigem, Long idContaDestino, double valor) {
        ContaBancaria contaOrigem = contaBancariaRepository.findById(idContaOrigem)
                .orElseThrow(() -> new RuntimeException("Conta de origem não encontrada"));
        ContaBancaria contaDestino = contaBancariaRepository.findById(idContaDestino)
                .orElseThrow(() -> new RuntimeException("Conta de destino não encontrada"));

        if (contaOrigem.getSaldo().compareTo(BigDecimal.valueOf(valor)) < 0) {
            throw new RuntimeException("Saldo insuficiente");
        }

        contaOrigem.setSaldo(contaOrigem.getSaldo().subtract(BigDecimal.valueOf(valor)));
        contaDestino.setSaldo(contaDestino.getSaldo().add(BigDecimal.valueOf(valor)));

        contaBancariaRepository.save(contaOrigem);
        contaBancariaRepository.save(contaDestino);

        // Registrar transação de débito
        Transacoes transacaoDebito = new Transacoes();
        transacaoDebito.setValor(BigDecimal.valueOf(valor));
        transacaoDebito.setTipoTransacao("TRANSFERENCIA_DEBITO");
        transacaoDebito.setContaOrigem(contaOrigem);
        transacaoDebito.setDataHora(LocalDateTime.now());
        transacoesRepository.save(transacaoDebito);

        // Registrar transação de crédito
        Transacoes transacaoCredito = new Transacoes();
        transacaoCredito.setValor(BigDecimal.valueOf(valor));
        transacaoCredito.setTipoTransacao("TRANSFERENCIA_CREDITO");
        transacaoCredito.setContaOrigem(contaDestino);
        transacaoCredito.setDataHora(LocalDateTime.now());
        transacoesRepository.save(transacaoCredito);
    }

    // Puxar extrato
    public List<Transacoes> obterExtrato(Long idConta) {
        return transacoesRepository.findByContaOrigemId(idConta);
    }
}

*/