package com.avapay.model;

import jakarta.persistence.*;

@Entity
@Table(name = "cadastro_pix")
public class CadastroPix {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pix")
    private Long idPix;

    @Column(name = "tipo_pix", nullable = false, length = 50)
    private String tipoPix;

    @Column(name = "chave_pix", length = 255)
    private String chavePix;

    @ManyToOne
    @JoinColumn(name = "id_conta", nullable = false)
    private ContaBancaria contaBancaria; 

    // Getters e Setters
    public Long getIdPix() {
        return idPix;
    }

    public void setIdPix(Long idPix) {
        this.idPix = idPix;
    }

    public String getTipoPix() {
        return tipoPix;
    }

    public void setTipoPix(String tipoPix) {
        this.tipoPix = tipoPix;
    }

    public String getChavePix() {
        return chavePix;
    }

    public void setChavePix(String chavePix) {
        this.chavePix = chavePix;
    }

    public ContaBancaria getContaBancaria() {
        return contaBancaria;
    }

    public void setContaBancaria(ContaBancaria contaBancaria) {
        this.contaBancaria = contaBancaria;
    }
}
