package com.projeto.avapay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoAvapayApplicationTests {

	@Test
	void contextLoads() {
	}

}
