package com.projeto.avapay.exceptions;

public class InsufficientBalanceException extends Exception {

	public InsufficientBalanceException(String string) {
		
	}

}
